
//(function(){
window.MyDApp_debug = (function(){
	var myDApp = new DCLib.DApp({slug : 'dicegame_v3'})

	// Banroller side code
	// console.log(myDApp)

	return myDApp
})()

