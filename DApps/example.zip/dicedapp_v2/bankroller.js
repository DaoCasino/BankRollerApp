
//(function(){
window.MyDApp_debug = (function(){
	var myDApp = new DCLib.DApp({code : 'dicedapp_v2'})

	// Banroller side code
	// console.log(myDApp)

	return myDApp
})()

