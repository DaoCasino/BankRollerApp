
//(function(){
window.MultDApp = (function(){
	let DApp = new DCLib.DApp({slug : 'dicegame_v3'})
	
	return DApp
})()

