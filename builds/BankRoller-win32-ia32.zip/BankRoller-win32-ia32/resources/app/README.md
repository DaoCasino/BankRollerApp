<h1>Chrome extension for bankroller</h1>
Download
https://github.com/DaoCasino/BankRollerApp/blob/master/builds/ChromeExtension/ChromeExt_BankRoller.crx

and install chrome extension:
chrome://extensions/

deploy game contract, send BETs and get play!


<h2>Develop</h2>
You need nodejs 6.9+
<pre>npm install && npm start</pre>
