window.rollDice = (function(){
	



    return function (){

    };
}());